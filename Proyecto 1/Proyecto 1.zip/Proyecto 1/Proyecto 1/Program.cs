﻿
//ALMACENAR LA INFORMACIÓN DE LOS EQUIPOS
using System;
using System.Collections.Generic;
//Console.ForegroundColor = ConsoleColor.DarkYellow;
//Console.BackgroundColor = ConsoleColor.DarkGray;
//Console.Clear();
    string[] equipos = new string[8];
    for (int i = 0; i < equipos.Length; i++)
    {
        Console.WriteLine("Ingrese el " + (i + 1) + " equipo");
        string input = Console.ReadLine();

        equipos[i] = input;
    }
Console.Clear();
    Console.WriteLine("Ingresar información de los equipos");
    int[,] partidos = new int[8, 3];
    for (int i = 0; i < 8; i++)
    {
        int j = 0;
        Console.WriteLine("Ingrese los partidos ganados por el " + equipos[i] + " (Puede jugar un máximo de 4 partidos)");
        partidos[i, j] = int.Parse(Console.ReadLine());
        j++;
        Console.WriteLine("Ingrese los partidos perdidos por el " + equipos[i] + " equipo (Puede jugar un máximo de 4 partidos)");
        partidos[i, j] = int.Parse(Console.ReadLine());
        j++;
        Console.WriteLine("Ingrese los partidos empatados por el " + equipos[i] + " equipo (Puede jugar un máximo de 4 partidos)");
        partidos[i, j] = int.Parse(Console.ReadLine());
    if(partidos[i, 0] + partidos[i,1] + partidos[i,2] != 4)
    {
        Console.WriteLine("Ingrese una cantidad de partidos correcta");
        i--;
    }
    
    }

Console.Clear();

//CREACÍÓN DEL MENÚ DE OPCIONES
menu:
string eleccion = "";
Console.WriteLine("Menú Principal"); 
Console.WriteLine("1. Editar equipos");
Console.WriteLine("2. Mostrar información de equipos ingresados");
Console.WriteLine("3. Iniciar simulación");
Console.WriteLine("4. Salir");
eleccion = Console.ReadLine();
Console.Clear();

#region editarequipo
if (eleccion == "1")
{
    bool seguir = true;
    int editar;
    do
    {
    edicion:
        Console.WriteLine("Ingrese el número del equipo que desea editar");
        bool comprobar = Int32.TryParse(Console.ReadLine(), out editar);
        if (comprobar) {
             
                 Console.WriteLine("Ingrese el nuevo equipo");
                   equipos[editar] = Console.ReadLine();
            if(editar >= 1 || editar <= 8) {

                do
                    {
                        preguntas:
                        Console.WriteLine("Desea editar otro equipo? (Ingresar si o no)");
                        string opcion = Console.ReadLine();
                        if (opcion == "no" || opcion == "NO") break;
                        else goto edicion;
                    } while (seguir == true);
            } else Console.WriteLine("FAVOR INGRESAR UN VALOR ENTRE 1 Y 8");

        } else Console.WriteLine("FAVOR INGRESAR UN ENTERO");
        goto menu;

    }
    while (!seguir); 
}
#endregion

#region mostrarequipo
if (eleccion == "2")

{
    for (int i = 0; i < equipos.Length; i++)
{
    Console.WriteLine("Su equipo en la posición " + (i + 1) + " es " + equipos[i]);
        Console.WriteLine("Y ha ganado " + partidos[i, 0] + " partidos, a empatado " + partidos[i, 1] + " partidos, y ha perdido " + partidos[i, 2] + " partidos");
}
}
#endregion

#region simularjuego
if (eleccion == "3")
{
eleccion_de_equipos:
    Random rdn = new Random();
    int vs_equipo1 = rdn.Next(0, 4) + 4;
    int vs_equipo2 = rdn.Next(0, 4) + 4;
    int vs_equipo3 = rdn.Next(0, 4) + 4;
    int vs_equipo4 = rdn.Next(0, 4) + 4;
    if (vs_equipo1 == vs_equipo2 || vs_equipo1 == vs_equipo3 || vs_equipo1 == vs_equipo4 || vs_equipo2 == vs_equipo3 || vs_equipo2 == vs_equipo4 || vs_equipo3 == vs_equipo4)
    {
        goto eleccion_de_equipos;
    }
    else
    {
        int ganador1 = 1, ganador2 = 3, ganador3 = 5, ganador4 = 7;
        int ganador_s1 = 1, ganador_s2 = 5;
        int ganador = 1;
        int gol_cuartos1 = 0;
        int gol_cuartos2 = 0;
        int gol_cuartos3 = 0;
        int gol_cuartos4 = 0;
        int gol_cuartos5 = 0;
        int gol_cuartos6 = 0;
        int gol_cuartos7 = 0;
        int gol_cuartos8 = 0;
        int gol_semis1 = 0;
        int gol_semis2 = 0;
        int gol_semis3 = 0;
        int gol_semis4 = 0;
        int gol_final1 = 0, gol_final2 = 0;
        Console.WriteLine("El equipo 1 se enfrentará contra el equipo: " + equipos[vs_equipo1]);
        Console.WriteLine("El equipo 2 se enfrentará contra el equipo: " + equipos[vs_equipo2]);
        Console.WriteLine("El equipo 3 se enfrentará contra el equipo: " + equipos[vs_equipo3]);
        Console.WriteLine("El equipo 4 se enfrentará contra el equipo: " + equipos[vs_equipo4]);
        Console.ReadKey();
        Console.Clear();
        double poder_equipo1 = ((partidos[0, 0] * 0.7) - (partidos[0, 1] * 0.2) + (partidos[0, 2] * 0.1)) / 4;
        double poder_equipo2 = ((partidos[1, 0] * 0.7) - (partidos[1, 1] * 0.2) + (partidos[1, 2] * 0.1)) / 4;
        double poder_equipo3 = ((partidos[2, 0] * 0.7) - (partidos[2, 1] * 0.2) + (partidos[2, 2] * 0.1)) / 4;
        double poder_equipo4 = ((partidos[3, 0] * 0.7) - (partidos[3, 1] * 0.2) + (partidos[3, 2] * 0.1)) / 4;
        double poder_equipo5 = (partidos[vs_equipo1, 0] * 0.7) - (partidos[vs_equipo1, 1] * 0.2) + (partidos[vs_equipo1, 2] * 0.1) / 4;
        double poder_equipo6 = (partidos[vs_equipo2, 0] * 0.7) - (partidos[vs_equipo2, 1] * 0.2) + (partidos[vs_equipo2, 2] * 0.1) / 4;
        double poder_equipo7 = (partidos[vs_equipo3, 0] * 0.7) - (partidos[vs_equipo3, 1] * 0.2) + (partidos[vs_equipo3, 2] * 0.1) / 4;
        double poder_equipo8 = (partidos[vs_equipo4, 0] * 0.7) - (partidos[vs_equipo4, 1] * 0.2) + (partidos[vs_equipo4, 2] * 0.1) / 4;
        for (int i = 0; i < 5; i++)
        {
            Random goles = new Random();
            double gol = goles.Next(0, 10) / 10;

            if (gol < poder_equipo1)
            {

                gol_cuartos1++;
            }
            if (gol < poder_equipo2)
            {

                gol_cuartos2++;
            }


            if (gol < poder_equipo3)
            {

                gol_cuartos3++;
            }
            if (gol < poder_equipo4)
            {

                gol_cuartos4++;
            }

            if (gol < poder_equipo5)
            {

                gol_cuartos5++;
            }
            if (gol < poder_equipo6)
            {

                gol_cuartos6++;
            }
            if (gol < poder_equipo7)
            {

                gol_cuartos7++;
            }
            if (gol < poder_equipo8)
            {
                gol_cuartos8++;
            }
        }

        if (gol_cuartos1 > gol_cuartos2)
        {
            Console.WriteLine("El equipo 1 es el ganador");
            ganador1 = 1;
        }
        if (gol_cuartos2 > gol_cuartos1)
        {
            Console.WriteLine("El equipo 2 es el ganador");
            ganador1 = 2;
        }
        if (gol_cuartos3 > gol_cuartos4)
        {
            Console.WriteLine("El equipo 1 es el ganador");
            ganador2 = 3;
        }
        if (gol_cuartos4 > gol_cuartos3)
        {
            Console.WriteLine("El equipo 2 es el ganador");
            ganador2 = 4;
        }
        if (gol_cuartos5 > gol_cuartos6)
        {
            Console.WriteLine("El equipo 1 es el ganador");
            ganador3 = 5;
        }
        if (gol_cuartos6 > gol_cuartos5)
        {
            Console.WriteLine("El equipo 2 es el ganador");
             ganador3 = 6;
        }
        if (gol_cuartos7 > gol_cuartos8)
        {
            Console.WriteLine("El equipo 1 es el ganador");
             ganador4 = 7;
        }
        if (gol_cuartos8 > gol_cuartos7)
        {
            Console.WriteLine("El equipo 2 es el ganador");
             ganador4 = 8;
        }
        Console.WriteLine("El equipo que gano el primer partido fue: " + equipos[ganador1 - 1]);
        Console.WriteLine("El equipo que gano el segundo partido fue: " + equipos[ganador2 - 1]);
        Console.WriteLine("El equipo que gano el terecer partido fue: " + equipos[ganador3 - 1]);
        Console.WriteLine("El equipo que gano el cuarto partido fue: " + equipos[ganador4 - 1]);
        Console.WriteLine("Pulse enter para ir a los cuartos de final");
        Console.Clear();
        double poder_ganador_c1 = ((partidos[0, 0] * 0.7) - (partidos[0, 1] * 0.2) + (partidos[0, 2] * 0.1)) / 5;
        double poder_ganador_c2 = ((partidos[1, 0] * 0.7) - (partidos[1, 1] * 0.2) + (partidos[1, 2] * 0.1)) / 5;
        double poder_ganador_c3 = ((partidos[2, 0] * 0.7) - (partidos[2, 1] * 0.2) + (partidos[2, 2] * 0.1)) / 5;
        double poder_ganador_c4 = ((partidos[3, 0] * 0.7) - (partidos[3, 1] * 0.2) + (partidos[3, 2] * 0.1)) / 5;
        for (int i = 0; i < 5; i++)
        {
            Random goles = new Random();
            double gol = goles.Next(0, 10) / 10;

            if (gol < poder_equipo1)
            {

                gol_semis1++;
            }
            if (gol < poder_equipo2)
            {

                gol_semis1++;
            }


            if (gol < poder_equipo3)
            {

                gol_semis2++;
            }
            if (gol < poder_equipo4)
            {

                gol_semis2++;
            }
        }

        if (gol_semis1 > gol_semis2)
        {
            Console.WriteLine("El equipo 1 es el ganador");
            ganador_s1 = 1;
        }
        if (gol_semis2 > gol_semis1)
        {
            Console.WriteLine("El equipo 2 es el ganador");
            ganador_s1 = 2;
        }
        if (gol_semis3 > gol_semis4)
        {
            Console.WriteLine("El equipo 1 es el ganador");
            ganador_s2 = 3;
        }
        if (gol_semis4 > gol_semis3)
        {
            Console.WriteLine("El equipo 2 es el ganador");
            ganador_s2 = 4;
        }
        Console.WriteLine("El equipo que gano la primera semifinal fue: " + equipos[ganador1 - 1]);
        Console.WriteLine("El equipo que gano la segunda semifinal fue: " + equipos[ganador2 - 1]);
        Console.WriteLine("Pulste enter para ir a la final");
        double poder_ganador_f1 = ((partidos[0, 0] * 0.7) - (partidos[0, 1] * 0.2) + (partidos[0, 2] * 0.1)) / 5;
        double poder_ganador_f2 = ((partidos[1, 0] * 0.7) - (partidos[1, 1] * 0.2) + (partidos[1, 2] * 0.1)) / 5;
        for (int i = 0; i < 5; i++)
        {
            Random goles = new Random();
            double gol = goles.Next(0, 10) / 10;

            if (gol < poder_ganador_f1)
            {

                gol_final1++;
            }
            if (gol < poder_ganador_f2)
            {

                gol_final2++;
            }
        }

        if (gol_final1 > gol_cuartos2)
        {
            Console.WriteLine("El equipo 1 es el ganador");
            ganador = 1;
        }
        if (gol_final2 > gol_cuartos1)
        {
            Console.WriteLine("El equipo 2 es el ganador");
            ganador = 2;
        }
        Console.WriteLine("El equipo ganador es: " + equipos[ganador]);
    }
}
 

#endregion

if (eleccion == "4")
    {
        Environment.Exit(0);
    }